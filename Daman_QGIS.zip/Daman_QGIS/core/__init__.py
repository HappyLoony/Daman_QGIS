# -*- coding: utf-8 -*-
"""
Core functionality for Daman_QGIS plugin
"""
