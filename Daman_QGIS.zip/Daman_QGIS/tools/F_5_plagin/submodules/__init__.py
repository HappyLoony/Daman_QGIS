# -*- coding: utf-8 -*-
"""
Субмодули для F_5_1_CheckDependencies
Проверка и установка зависимостей плагина Daman_QGIS
"""
