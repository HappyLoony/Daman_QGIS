# -*- coding: utf-8 -*-
"""
Database module for Daman_QGIS plugin.
Handles reference database and project database operations.
"""
